// Form.js
import React, { useState } from 'react';
import { Paper, TextField, Typography, Button } from '@mui/material';
import { StyledForm, StyledPaper, StyledButtonSubmit } from './styles';
import FileBase from 'react-file-base64';
import { useDispatch } from 'react-redux';
import { createPost } from '../../actions/posts';

const Form = () => {
  const [postData, setPostData] = useState({ creator: '', title: '', message: '', tags: '', selectedFile: '' });
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(createPost(postData));
    clear();
  };

  const clear = () => {
    setPostData({ creator: '', title: '', message: '', tags: '', selectedFile: '' });
  };

  return (
    <StyledPaper elevation={3}>
      <StyledForm autoComplete="off" noValidate onSubmit={handleSubmit}>
        <Typography variant="h6">Creating a Memory</Typography>
        <TextField 
          name="creator" 
          variant="outlined" 
          label="Creator" 
          fullWidth 
          value={postData.creator} 
          onChange={(e) => setPostData({ ...postData, creator: e.target.value })} 
        />
        <TextField 
          name="title" 
          variant="outlined" 
          label="Title" 
          fullWidth 
          value={postData.title} 
          onChange={(e) => setPostData({ ...postData, title: e.target.value })} 
        />
        <TextField 
          name="message" 
          variant="outlined" 
          label="Message" 
          fullWidth 
          value={postData.message} 
          onChange={(e) => setPostData({ ...postData, message: e.target.value })}
          multiline 
          rows={4} 
        />
        <TextField 
          name="tags" 
          variant="outlined" 
          label="Tags (comma separated)" 
          fullWidth 
          value={postData.tags} 
          onChange={(e) => setPostData({ ...postData, tags: e.target.value.split(',') })} // Assuming you want to split tags by commas
        />
        <div style={{ width: '97%', margin: '10px 0' }}>
          <FileBase 
            type="file" 
            multiple={false} 
            onDone={({ base64 }) => setPostData({ ...postData, selectedFile: base64 })} 
          />
        </div>
        <StyledButtonSubmit variant="contained" color="primary" size="large" fullWidth type="submit">
          Submit
        </StyledButtonSubmit>
        <Button variant="contained" color="secondary" size="large" fullWidth onClick={clear}>
          Clear
        </Button>
      </StyledForm>
    </StyledPaper>
  );
};

export default Form;
