// styles.js
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

export const StyledForm = styled('form')(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'center',
  '& .MuiTextField-root': {
    margin: theme.spacing(1),
  },
  '& .MuiButton-root': {
    margin: theme.spacing(1),
  },
}));

export const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
}));

export const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: theme.spacing(1),
}));

export const StyledButtonSubmit = styled(Button)(({ theme }) => ({
  marginBottom: theme.spacing(1),
}));
