// Posts/Posts.js
import React from 'react';
import { MainContainer, SmMargin, ActionDiv } from './styles';
import Post from './Post/Post';
import { useSelector } from 'react-redux';

const Posts = () => {
  // Your logic here...

  const posts = useSelector((state)=>state.posts);
  console.log(posts);
  return (
    <MainContainer>
      {/* Your Posts logic */}
      <Post />
      
      {/* Applying SmMargin and ActionDiv wherever necessary */}
    </MainContainer>
  );
};

export default Posts;
