// Post/Post.js
import React from 'react';
import { Typography } from '@mui/material'; // Import Typography from MUI
import { StyledPaper, StyledTitle, StyledButton } from './styles';

const Post = () => {
  return (
    <StyledPaper elevation={3}>
      <StyledTitle variant="h5" component="h2">
        Post Title
      </StyledTitle>
      <Typography variant="body2" color="textSecondary" component="p">
        This is a media card. You can use this section to describe the content.
      </Typography>
      <StyledButton variant="contained" color="primary">
        Learn More
      </StyledButton>
    </StyledPaper>
  );
};

export default Post;
