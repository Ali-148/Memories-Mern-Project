// Post/styles.js
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';



export const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  margin: theme.spacing(2, 0),
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}));

export const StyledTitle = styled(Typography)({
  marginBottom: '16px',
  fontWeight: 'bold',
});

export const StyledButton = styled(Button)(({ theme }) => ({
  marginTop: theme.spacing(1),
}));
